#!/bin/bash

##  This launches the about Dialog for Coopertronic OS

python /usr/share/about/dialog.py